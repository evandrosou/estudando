
numero = int(input("Digite um numero:"))
a = 0
b = 1
contador = 0
while contador < numero:
    print(a)
    print(b)
    a = a + b
    b = b + a
    contador += 1
    if a == numero:
        print("Ação bem sucedida!")
    if b == numero:
        print("Ação bem sucedida!")



